<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('reviews', function (Blueprint $table) {
            $table->id();

            // =========================
            // USER RELATION
            // =========================
            $table->foreignId('user_id')
                ->constrained()
                ->cascadeOnDelete();

            // =========================
            // ORDER RELATION
            // =========================
            $table->foreignId('order_id')
                ->constrained()
                ->cascadeOnDelete();

            // =========================
            // PRODUCT RELATION
            // =========================
            $table->foreignId('product_id')
                ->constrained()
                ->cascadeOnDelete();

            // =========================
            // RATING ONLY
            // =========================
            $table->unsignedTinyInteger('rating'); // 1 - 5

            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('reviews');
    }
};