<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

use App\Models\Product;

class OrderItem extends Model
{
    protected $fillable = [

        'order_id',

        'product_id',

        'qty',

        'price',

        'note'
    ];

    // =========================
    // RELATION PRODUCT
    // =========================
    public function product()
    {
        return $this->belongsTo(
            Product::class
        );
    }
}